include 'emu8086.inc'
call scan_num  
mov arr[si],cx
call print_num
inc si

call scan_num
mov arr[si],cx
call print_num
inc si

call scan_num
mov arr[si],cx
call print_num





arr dw 1,2,3
si dw 0
define_scan_num
define_print_num
define_print_num_uns
include'emu8086.inc'
print 'enter the array size'
call scan_num
mov n,cx
print 'enter array elements'
call scan_num
mov ax,cx
cmp ax,si
je abc
